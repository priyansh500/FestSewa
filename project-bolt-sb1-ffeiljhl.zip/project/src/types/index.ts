export interface User {
  id: string;
  name: string;
  email: string;
  role: 'participant' | 'organizer';
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  venue: string;
  capacity: number;
  registeredCount: number;
  type: 'individual' | 'team';
  category: 'technical' | 'cultural' | 'sports';
}

export interface Quiz {
  id: string;
  title: string;
  description: string;
  duration: number; // in minutes
  questions: Question[];
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
}

export interface Registration {
  id: string;
  userId: string;
  eventId: string;
  status: 'pending' | 'confirmed' | 'cancelled';
  teamName?: string;
  teamMembers?: string[];
}

export interface QuizResult {
  id: string;
  userId: string;
  quizId: string;
  score: number;
  completedAt: string;
}