import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Bell, Calendar, Home, Layout as LayoutIcon, LogIn, UserCircle } from 'lucide-react';
import { useStore } from '../store';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { user, notifications } = useStore();
  const location = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-indigo-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="flex items-center space-x-2">
                <LayoutIcon className="h-8 w-8" />
                <span className="font-bold text-xl">Tfestx</span>
              </Link>
              <div className="hidden md:block ml-10">
                <div className="flex items-baseline space-x-4">
                  <NavLink to="/" icon={<Home className="h-4 w-4" />}>
                    Home
                  </NavLink>
                  <NavLink to="/events" icon={<Calendar className="h-4 w-4" />}>
                    Events
                  </NavLink>
                  {user && (
                    <NavLink to="/dashboard" icon={<UserCircle className="h-4 w-4" />}>
                      Dashboard
                    </NavLink>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Bell className="h-6 w-6 cursor-pointer" />
                {notifications.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-xs rounded-full h-4 w-4 flex items-center justify-center">
                    {notifications.length}
                  </span>
                )}
              </div>
              {!user ? (
                <Link
                  to="/login"
                  className="flex items-center space-x-1 bg-indigo-500 px-4 py-2 rounded-md hover:bg-indigo-400"
                >
                  <LogIn className="h-4 w-4" />
                  <span>Login</span>
                </Link>
              ) : (
                <div className="flex items-center space-x-2">
                  <img
                    src={`https://api.dicebear.com/7.x/initials/svg?seed=${user.name}`}
                    alt="avatar"
                    className="h-8 w-8 rounded-full"
                  />
                  <span>{user.name}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">{children}</main>
    </div>
  );
}

interface NavLinkProps {
  to: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

function NavLink({ to, icon, children }: NavLinkProps) {
  const location = useLocation();
  const isActive = location.pathname === to;

  return (
    <Link
      to={to}
      className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
        isActive
          ? 'bg-indigo-700 text-white'
          : 'text-indigo-100 hover:bg-indigo-500'
      }`}
    >
      {icon}
      <span>{children}</span>
    </Link>
  );
}