import { create } from 'zustand';
import type { User, Event, Quiz, Registration, QuizResult } from '../types';

interface AppState {
  user: User | null;
  events: Event[];
  registrations: Registration[];
  quizzes: Quiz[];
  quizResults: QuizResult[];
  notifications: string[];
  setUser: (user: User | null) => void;
  addRegistration: (registration: Registration) => void;
  addQuizResult: (result: QuizResult) => void;
  addNotification: (message: string) => void;
}

export const useStore = create<AppState>((set) => ({
  user: null,
  events: [],
  registrations: [],
  quizzes: [],
  quizResults: [],
  notifications: [],
  setUser: (user) => set({ user }),
  addRegistration: (registration) =>
    set((state) => ({
      registrations: [...state.registrations, registration],
    })),
  addQuizResult: (result) =>
    set((state) => ({
      quizResults: [...state.quizResults, result],
    })),
  addNotification: (message) =>
    set((state) => ({
      notifications: [...state.notifications, message],
    })),
}));