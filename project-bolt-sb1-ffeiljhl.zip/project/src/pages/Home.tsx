import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Users, Brain, Trophy } from 'lucide-react';

export function Home() {
  return (
    <div className="space-y-12">
      <section className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Welcome to Tfestx 2024
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Join us for an exciting celebration of talent, creativity, and innovation.
          Register now for events, participate in challenges, and win amazing prizes!
        </p>
      </section>

      <section className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <FeatureCard
          icon={<Calendar className="h-8 w-8" />}
          title="Events"
          description="Explore our diverse range of technical, cultural, and sports events"
          link="/events"
        />
        <FeatureCard
          icon={<Users className="h-8 w-8" />}
          title="Team Up"
          description="Form teams and participate in group events and competitions"
          link="/events?type=team"
        />
        <FeatureCard
          icon={<Brain className="h-8 w-8" />}
          title="Quizzes"
          description="Test your knowledge with our interactive quiz challenges"
          link="/quizzes"
        />
        <FeatureCard
          icon={<Trophy className="h-8 w-8" />}
          title="Leaderboard"
          description="Track scores and rankings across all competitions"
          link="/dashboard"
        />
      </section>

      <section className="bg-indigo-50 rounded-xl p-8 mt-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Featured Events</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <EventCard
            title="Hackathon 2024"
            image="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80&w=800"
            date="March 15, 2024"
            category="technical"
          />
          <EventCard
            title="Battle of Bands"
            image="https://images.unsplash.com/photo-1501612780327-45045538702b?auto=format&fit=crop&q=80&w=800"
            date="March 16, 2024"
            category="cultural"
          />
          <EventCard
            title="Sports Tournament"
            image="https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&q=80&w=800"
            date="March 17, 2024"
            category="sports"
          />
        </div>
      </section>
    </div>
  );
}

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  link: string;
}

function FeatureCard({ icon, title, description, link }: FeatureCardProps) {
  return (
    <Link
      to={link}
      className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow"
    >
      <div className="text-indigo-600 mb-4">{icon}</div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </Link>
  );
}

interface EventCardProps {
  title: string;
  image: string;
  date: string;
  category: string;
}

function EventCard({ title, image, date, category }: EventCardProps) {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md">
      <img src={image} alt={title} className="w-full h-48 object-cover" />
      <div className="p-4">
        <span className="text-xs font-semibold text-indigo-600 uppercase">
          {category}
        </span>
        <h3 className="text-lg font-semibold text-gray-900 mt-1">{title}</h3>
        <p className="text-gray-600 text-sm mt-1">{date}</p>
      </div>
    </div>
  );
}