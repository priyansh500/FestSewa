import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Filter, Search, Calendar, Users, MapPin } from 'lucide-react';
import { useStore } from '../store';
import type { Event } from '../types';

export function Events() {
  const [category, setCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // In a real app, this would come from the store
  const events: Event[] = [
    {
      id: '1',
      title: 'Hackathon 2024',
      description: 'A 24-hour coding challenge to build innovative solutions',
      date: '2024-03-15',
      time: '09:00',
      venue: 'Main Auditorium',
      capacity: 200,
      registeredCount: 150,
      type: 'team',
      category: 'technical'
    },
    {
      id: '2',
      title: 'Battle of Bands',
      description: 'Annual music competition featuring college bands',
      date: '2024-03-16',
      time: '18:00',
      venue: 'Open Air Theatre',
      capacity: 500,
      registeredCount: 300,
      type: 'team',
      category: 'cultural'
    },
    {
      id: '3',
      title: 'Coding Quiz',
      description: 'Test your programming knowledge',
      date: '2024-03-17',
      time: '14:00',
      venue: 'CS Lab',
      capacity: 100,
      registeredCount: 45,
      type: 'individual',
      category: 'technical'
    }
  ];

  const filteredEvents = events.filter(event => {
    const matchesCategory = category === 'all' || event.category === category;
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h1 className="text-3xl font-bold text-gray-900">Events</h1>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search events..."
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <select
            className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="all">All Categories</option>
            <option value="technical">Technical</option>
            <option value="cultural">Cultural</option>
            <option value="sports">Sports</option>
          </select>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredEvents.map((event) => (
          <Link
            key={event.id}
            to={`/events/${event.id}`}
            className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow overflow-hidden"
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  event.category === 'technical' ? 'bg-blue-100 text-blue-800' :
                  event.category === 'cultural' ? 'bg-purple-100 text-purple-800' :
                  'bg-green-100 text-green-800'
                }`}>
                  {event.category}
                </span>
                <span className={`flex items-center ${
                  event.registeredCount >= event.capacity ? 'text-red-600' : 'text-green-600'
                }`}>
                  <Users className="h-4 w-4 mr-1" />
                  {event.registeredCount}/{event.capacity}
                </span>
              </div>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{event.title}</h3>
              <p className="text-gray-600 mb-4">{event.description}</p>
              
              <div className="space-y-2 text-sm text-gray-500">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>{new Date(event.date).toLocaleDateString()} at {event.time}</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-2" />
                  <span>{event.venue}</span>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}