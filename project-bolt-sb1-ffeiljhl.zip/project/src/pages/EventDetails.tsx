import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Calendar, MapPin, Users, Clock, Trophy } from 'lucide-react';
import { useStore } from '../store';

export function EventDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useStore();

  // In a real app, this would come from the store
  const event = {
    id: '1',
    title: 'Hackathon 2024',
    description: 'Join us for an exciting 24-hour coding challenge where you\'ll work in teams to build innovative solutions to real-world problems. This is your chance to showcase your programming skills, creativity, and problem-solving abilities while competing for amazing prizes.',
    date: '2024-03-15',
    time: '09:00',
    venue: 'Main Auditorium',
    capacity: 200,
    registeredCount: 150,
    type: 'team',
    category: 'technical',
    rules: [
      'Teams must consist of 2-4 members',
      'All team members must be currently enrolled students',
      'Participants must bring their own laptops',
      'Internet access will be provided',
      'Use of AI tools is allowed but must be disclosed'
    ],
    prizes: {
      first: '₹50,000',
      second: '₹30,000',
      third: '₹20,000'
    }
  };

  const handleRegister = () => {
    if (!user) {
      navigate('/login', { state: { redirect: `/events/${id}` } });
      return;
    }
    // Handle registration logic
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white rounded-lg shadow-md p-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-gray-900">{event.title}</h1>
          <span className={`px-4 py-2 rounded-full text-sm font-medium ${
            event.category === 'technical' ? 'bg-blue-100 text-blue-800' :
            event.category === 'cultural' ? 'bg-purple-100 text-purple-800' :
            'bg-green-100 text-green-800'
          }`}>
            {event.category}
          </span>
        </div>

        <p className="text-gray-600 mb-8">{event.description}</p>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="space-y-4">
            <div className="flex items-center text-gray-600">
              <Calendar className="h-5 w-5 mr-3" />
              <span>{new Date(event.date).toLocaleDateString()} at {event.time}</span>
            </div>
            <div className="flex items-center text-gray-600">
              <MapPin className="h-5 w-5 mr-3" />
              <span>{event.venue}</span>
            </div>
            <div className="flex items-center text-gray-600">
              <Users className="h-5 w-5 mr-3" />
              <span>{event.registeredCount}/{event.capacity} registered</span>
            </div>
            <div className="flex items-center text-gray-600">
              <Clock className="h-5 w-5 mr-3" />
              <span>24 hours duration</span>
            </div>
          </div>

          <div className="bg-indigo-50 rounded-lg p-6">
            <div className="flex items-center mb-4">
              <Trophy className="h-6 w-6 text-indigo-600 mr-2" />
              <h3 className="text-lg font-semibold text-gray-900">Prizes</h3>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">1st Prize</span>
                <span className="font-semibold">{event.prizes.first}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">2nd Prize</span>
                <span className="font-semibold">{event.prizes.second}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">3rd Prize</span>
                <span className="font-semibold">{event.prizes.third}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Rules & Guidelines</h3>
          <ul className="list-disc list-inside space-y-2 text-gray-600">
            {event.rules.map((rule, index) => (
              <li key={index}>{rule}</li>
            ))}
          </ul>
        </div>

        <button
          onClick={handleRegister}
          className="w-full btn btn-primary py-3 text-lg"
          disabled={event.registeredCount >= event.capacity}
        >
          {event.registeredCount >= event.capacity
            ? 'Event Full'
            : user
            ? 'Register Now'
            : 'Login to Register'}
        </button>
      </div>
    </div>
  );
}