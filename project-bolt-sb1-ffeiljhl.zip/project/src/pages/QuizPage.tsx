import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Clock, AlertCircle } from 'lucide-react';
import { useStore } from '../store';

export function QuizPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [timeLeft, setTimeLeft] = useState(1800); // 30 minutes in seconds

  // In a real app, this would come from the store
  const quiz = {
    id: '1',
    title: 'Programming Basics',
    questions: [
      {
        id: '1',
        text: 'What is a variable?',
        options: [
          'A container for storing data values',
          'A mathematical equation',
          'A programming language',
          'A type of function'
        ],
        correctAnswer: 0
      },
      {
        id: '2',
        text: 'Which of the following is a loop structure?',
        options: [
          'if-else',
          'switch',
          'for',
          'try-catch'
        ],
        correctAnswer: 2
      },
      // Add more questions as needed
    ]
  };

  const handleAnswerSelect = (answerIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSubmit = () => {
    // Calculate score and save to store
    const score = selectedAnswers.reduce((acc, answer, index) => {
      return acc + (answer === quiz.questions[index].correctAnswer ? 1 : 0);
    }, 0);

    // Navigate to results
    navigate('/dashboard');
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-gray-900">{quiz.title}</h1>
          <div className="flex items-center text-gray-600">
            <Clock className="h-5 w-5 mr-2" />
            <span>{Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}</span>
          </div>
        </div>

        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-gray-500">
              Question {currentQuestion + 1} of {quiz.questions.length}
            </span>
            <span className="text-sm font-medium text-indigo-600">
              {Math.round(((currentQuestion + 1) / quiz.questions.length) * 100)}% Complete
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-indigo-600 h-2 rounded-full"
              style={{
                width: `${((currentQuestion + 1) / quiz.questions.length) * 100}%`
              }}
            />
          </div>
        </div>

        <div className="space-y-6">
          <h2 className="text-lg font-medium text-gray-900">
            {quiz.questions[currentQuestion].text}
          </h2>

          <div className="space-y-4">
            {quiz.questions[currentQuestion].options.map((option, index) => (
              <button
                key={index}
                className={`w-full p-4 text-left rounded-lg border ${
                  selectedAnswers[currentQuestion] === index
                    ? 'border-indigo-600 bg-indigo-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => handleAnswerSelect(index)}
              >
                <span className="font-medium">{String.fromCharCode(65 + index)}.</span>{' '}
                {option}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between mt-8">
          <button
            className="btn btn-secondary"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
          >
            Previous
          </button>
          {currentQuestion === quiz.questions.length - 1 ? (
            <button
              className="btn btn-primary"
              onClick={handleSubmit}
              disabled={selectedAnswers.length !== quiz.questions.length}
            >
              Submit Quiz
            </button>
          ) : (
            <button
              className="btn btn-primary"
              onClick={handleNext}
              disabled={selectedAnswers[currentQuestion] === undefined}
            >
              Next Question
            </button>
          )}
        </div>

        {selectedAnswers[currentQuestion] === undefined && (
          <div className="flex items-center justify-center mt-4 text-yellow-600">
            <AlertCircle className="h-5 w-5 mr-2" />
            <span>Please select an answer to continue</span>
          </div>
        )}
      </div>
    </div>
  );
}