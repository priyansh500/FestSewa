import React from 'react';
import { Link } from 'react-router-dom';
import { Brain, Clock, Award, ArrowRight } from 'lucide-react';

export function Quizzes() {
  // In a real app, this would come from the store
  const quizzes = [
    {
      id: '1',
      title: 'Programming Basics',
      description: 'Test your knowledge of fundamental programming concepts',
      duration: 30,
      questions: 20,
      difficulty: 'Beginner'
    },
    {
      id: '2',
      title: 'Data Structures',
      description: 'Challenge yourself with advanced data structure problems',
      duration: 45,
      questions: 25,
      difficulty: 'Advanced'
    },
    {
      id: '3',
      title: 'Web Development',
      description: 'Explore your understanding of modern web technologies',
      duration: 40,
      questions: 30,
      difficulty: 'Intermediate'
    }
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Quiz Challenges</h1>
        <div className="flex items-center space-x-2">
          <Brain className="h-6 w-6 text-indigo-600" />
          <span className="text-gray-600">Test your knowledge</span>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {quizzes.map((quiz) => (
          <div key={quiz.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  quiz.difficulty === 'Beginner' ? 'bg-green-100 text-green-800' :
                  quiz.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {quiz.difficulty}
                </span>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-2">{quiz.title}</h3>
              <p className="text-gray-600 mb-4">{quiz.description}</p>

              <div className="space-y-2 mb-6">
                <div className="flex items-center text-gray-500">
                  <Clock className="h-4 w-4 mr-2" />
                  <span>{quiz.duration} minutes</span>
                </div>
                <div className="flex items-center text-gray-500">
                  <Award className="h-4 w-4 mr-2" />
                  <span>{quiz.questions} questions</span>
                </div>
              </div>

              <Link
                to={`/quizzes/${quiz.id}`}
                className="btn btn-primary w-full flex items-center justify-center"
              >
                <span>Start Quiz</span>
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}