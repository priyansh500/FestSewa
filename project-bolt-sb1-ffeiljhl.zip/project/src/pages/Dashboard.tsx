import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Trophy, Brain, Bell } from 'lucide-react';
import { useStore } from '../store';

export function Dashboard() {
  const { user, registrations, quizResults, notifications } = useStore();

  // In a real app, these would come from the store
  const upcomingEvents = [
    {
      id: '1',
      title: 'Hackathon 2024',
      date: '2024-03-15',
      time: '09:00',
      status: 'confirmed'
    },
    {
      id: '2',
      title: 'Coding Quiz',
      date: '2024-03-17',
      time: '14:00',
      status: 'pending'
    }
  ];

  const recentScores = [
    {
      id: '1',
      title: 'Programming Basics',
      score: 85,
      totalQuestions: 20,
      completedAt: '2024-02-28'
    },
    {
      id: '2',
      title: 'Data Structures',
      score: 92,
      totalQuestions: 25,
      completedAt: '2024-03-01'
    }
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <div className="flex items-center space-x-2">
          <img
            src={`https://api.dicebear.com/7.x/initials/svg?seed=${user?.name || 'Guest'}`}
            alt="avatar"
            className="h-10 w-10 rounded-full"
          />
          <div>
            <p className="font-medium text-gray-900">{user?.name || 'Guest'}</p>
            <p className="text-sm text-gray-500">{user?.email}</p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Upcoming Events</h2>
            <Calendar className="h-6 w-6 text-indigo-600" />
          </div>
          <div className="space-y-4">
            {upcomingEvents.map((event) => (
              <Link
                key={event.id}
                to={`/events/${event.id}`}
                className="block p-4 rounded-lg bg-gray-50 hover:bg-gray-100"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium text-gray-900">{event.title}</h3>
                    <p className="text-sm text-gray-500">
                      {new Date(event.date).toLocaleDateString()} at {event.time}
                    </p>
                  </div>
                  <span className={`text-sm px-2 py-1 rounded ${
                    event.status === 'confirmed'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {event.status}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Recent Scores</h2>
            <Trophy className="h-6 w-6 text-indigo-600" />
          </div>
          <div className="space-y-4">
            {recentScores.map((quiz) => (
              <div key={quiz.id} className="p-4 rounded-lg bg-gray-50">
                <h3 className="font-medium text-gray-900">{quiz.title}</h3>
                <div className="mt-2 flex items-center justify-between">
                  <div className="flex items-center">
                    <Brain className="h-4 w-4 text-gray-500 mr-1" />
                    <span className="text-sm text-gray-500">
                      {quiz.score}/{quiz.totalQuestions} correct
                    </span>
                  </div>
                  <span className="text-sm text-gray-500">
                    {new Date(quiz.completedAt).toLocaleDateString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Notifications</h2>
            <Bell className="h-6 w-6 text-indigo-600" />
          </div>
          <div className="space-y-4">
            {notifications.length > 0 ? (
              notifications.map((notification, index) => (
                <div key={index} className="p-4 rounded-lg bg-gray-50">
                  <p className="text-gray-600">{notification}</p>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center">No new notifications</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}